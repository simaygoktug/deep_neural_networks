#I preffered 12 hidden neurons, 0.9 momentum rate, 0.05 learning rate and 200 epochs as hyperparameters by result of grid search.
import math

class NeuralNetHolder:

    def __init__(self):
        # I am loading scale values first. (my data_preprocessing.py has generated it)
        self.load_scale()
        # Then I am loading the neural network weights. (my training.py has generated it)
        self.load_weights()

    def load_scale(self):
        # I am reading scale.txt (min,max pairs)
        f = open("scale.txt","r")
        lines = f.readlines()
        f.close()

        self.mins = []
        self.maxs = []

        # Each line has: min,max
        for ln in lines:
            p = ln.strip().split(",")
            self.mins.append(float(p[0]))
            self.maxs.append(float(p[1]))

    # I am using basic normalization function which I have learned in CE802 Machine Learning lecture.
    def norm(self, v, idx):
        return (v - self.mins[idx]) / (self.maxs[idx] - self.mins[idx] + 1e-8)

    # I am converting network output back to real scale.
    def unscale(self, v, idx):
        return v*(self.maxs[idx]-self.mins[idx]) + self.mins[idx]

    # I have used sigmoid activation function.
    def sig(self, x):
        return 1 / (1 + math.exp(-x))

    def load_weights(self):
        # I am reading weights from file now.
        f = open("weights.txt","r")
        lines = f.readlines()
        f.close()

        # INPUT → HIDDEN
        self.W1 = []
        for i in range(3):
            # weights are separated by commas
            row = [float(x) for x in lines[i].strip().split(",")]
            self.W1.append(row)

        # hidden
        b1_line = lines[3].replace("B1:","").strip().split(",")
        self.b1 = [float(x) for x in b1_line]

        # HIDDEN → OUTPUT
        self.W2 = []
        start = 4

        # 12 hidden neurons → 12 lines of weights
        for j in range(12):
            row = [float(x) for x in lines[start + j].strip().split(",")]
            self.W2.append(row)

        # output
        b2_line = lines[start + 12].replace("B2:","").strip().split(",")
        self.b2 = [float(x) for x in b2_line]

    def predict(self, input_row):
        # Input format: "x,y"
        p = input_row.split(",")
        x = float(p[0])
        y = float(p[1])

        # I am normalizing inputs.
        nx = self.norm(x, 0)
        ny = self.norm(y, 1)
        gravity = ny

        # Input vector for the network
        X = [nx, ny, gravity]

        # ------- HIDDEN LAYER -------
        h = []
        for j in range(12):
            s = self.b1[j]
            # weighted sum
            for i in range(3):
                s += X[i] * self.W1[i][j]
            # I am applying ReLU
            h.append(self.relu(s))

        # ------- OUTPUT LAYER -------
        out = []
        for k in range(2):
            s = self.b2[k] 
            for j in range(12):
                s += h[j] * self.W2[j][k]
            out.append(s)

        # Now converting outputs back to real scale.
        vel_y = self.unscale(out[0], 2)
        vel_x = self.unscale(out[1], 3)

        # I am adding extra upward thrust because of lack of predicted and real value for vel_y in control loop. 
        vel_y -= 0.8

        # Returning final velocity commands
        return [vel_x, vel_y]
