# My purpose for CE889 Final Assignment MLP task was creating neural network from scratch.
# 2 inputs -> 12 hidden neurons -> 2 outputs
# I decided to use Sigmoid activation because it is benefical on compuational work while backprop.
# I preffred learning rate as 0.05, momentum rate as 0.9, epochs as 200 according to my grid search results.

import csv
import random
import math

def load_csv(fname):
    # I can load the related csv file with this function.
    rows = []
    f = open(fname, "r")
    r = csv.reader(f)
    for row in r:
        rows.append([float(x) for x in row])
    f.close()
    return rows

# Now I am loading my normalized datasets which is produced by my data_preprocessing.py
train_data = load_csv("train_norm.csv")
val_data   = load_csv("val_norm.csv")
test_data  = load_csv("test_norm.csv")

# My network structure:
inp = 2
hid = 12
out = 2

# Firstly, random weight initialization
W1 = [[random.uniform(-0.5,0.5) for j in range(hid)] for i in range(inp)]
b1 = [0.0 for _ in range(hid)]

W2 = [[random.uniform(-0.5,0.5) for k in range(out)] for j in range(hid)]
b2 = [0.0 for _ in range(out)]

# I am storing momentums at first.
mW1 = [[0.0]*hid for _ in range(inp)]
mB1 = [0.0]*hid

mW2 = [[0.0]*out for _ in range(hid)]
mB2 = [0.0]*out

lr = 0.05
momentum = 0.9

# Sigmoid activation function
def sig(x):
    return 1 / (1 + math.exp(-x))

def sig_der(x):
    # Derivative using already activated value
    return x * (1 - x)

def forward(x):
    # forward pass
    h = []
    for j in range(hid):
        s = b1[j]
        for i in range(inp):
            s += x[i] * W1[i][j]
        h.append(sig(s))

    o = []
    for k in range(out):
        s = b2[k]
        for j in range(hid):
            s += h[j] * W2[j][k]
        o.append(sig(s))

    return h, o

def train_one(x, y):
    global W1, W2, b1, b2, mW1, mW2, mB1, mB2

    # Now computing activations
    h, o = forward(x)

    # output layer error
    e = [o[k] - y[k] for k in range(out)]
    delta_out = [e[k] * sig_der(o[k]) for k in range(out)]

    # hidden layer error
    delta_h = []
    for j in range(hid):
        s = 0
        for k in range(out):
            s += delta_out[k] * W2[j][k]
        delta_h.append(s * sig_der(h[j]))

    # Updating W2
    for j in range(hid):
        for k in range(out):
            grad = delta_out[k] * h[j]
            mW2[j][k] = momentum * mW2[j][k] - lr * grad
            W2[j][k] += mW2[j][k]

    # Updating b2
    for k in range(out):
        mB2[k] = momentum * mB2[k] - lr * delta_out[k]
        b2[k] += mB2[k]

    # Updating W1
    for i in range(inp):
        for j in range(hid):
            grad = delta_h[j] * x[i]
            mW1[i][j] = momentum * mW1[i][j] - lr * grad
            W1[i][j] += mW1[i][j]

    # Updating b1
    for j in range(hid):
        mB1[j] = momentum * mB1[j] - lr * delta_h[j]
        b1[j] += mB1[j]

def rmse(data):
    # I am computing RMSE for given dataset. I selected as performance metric for my model training.
    s = 0
    c = len(data) * out
    for row in data:
        x = row[:2]
        y = row[2:]
        _, o = forward(x)
        for k in range(out):
            s += (o[k] - y[k])**2
    return math.sqrt(s / c)

# ---------------- TRAINING LOOP ----------------
for ep in range(200):
    random.shuffle(train_data)

    for row in train_data:
        x = row[:2]
        y = row[2:]
        train_one(x, y)

    tr = rmse(train_data)
    vl = rmse(val_data)
    print("Epoch", ep, "| Train RMSE:", tr, "| Val RMSE:", vl)

# After training, computing final test RMSE.
print("\nFinal Test RMSE:", rmse(test_data), "\n")

# Saving weights to file. (Most important part, this file be read by NeuralNetHolder.py)
f = open("weights.txt", "w")

for i in range(inp):
    f.write(",".join([str(v) for v in W1[i]]) + "\n")

f.write("B1:" + ",".join([str(v) for v in b1]) + "\n")

for j in range(hid):
    f.write(",".join([str(v) for v in W2[j]]) + "\n")

f.write("B2:" + ",".join([str(v) for v in b2]) + "\n")
f.close()
