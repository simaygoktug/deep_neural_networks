#!/usr/bin/env python3
import random 
def read_csv(path):
    data = []
    f = open(path, "r")
    for line in f:
        line = line.strip()
        if line == "":
            continue
        parts = line.split(",")
        # I am expecting: x_dist, y_dist, vel_y, vel_x like Lab 2 script.
        if len(parts) != 4:
            continue
        row = [float(parts[0]), float(parts[1]), float(parts[2]), float(parts[3])]
        data.append(row)
    f.close()
    return data

def min_max(data):
    mins = [999999,999999,999999,999999]
    maxs = [-999999,-999999,-999999,-999999]
    for r in data:
        for i in range(4):
            if r[i] < mins[i]: mins[i] = r[i]
            if r[i] > maxs[i]: maxs[i] = r[i]
    return mins, maxs

def normalize_value(v, vmin, vmax):
    if vmax - vmin == 0: return 0
    return (v - vmin) / (vmax - vmin)

def write_csv(path, rows):
    f = open(path,"w")
    for r in rows:
        line = ",".join(str(x) for x in r)
        f.write(line + "\n")
    f.close()

def main():
    raw = read_csv("ce889_dataCollection.csv")

    # I am doing random shuffle before splitting
    random.shuffle(raw)
    mins, maxs = min_max(raw)

    # I am normalizing the data
    norm_data = []
    for r in raw:
        n = []
        for i in range(4):
            n.append(normalize_value(r[i], mins[i], maxs[i]))
        norm_data.append(n)

    total = len(norm_data)
    t70 = int(total * 0.70)
    t85 = int(total * 0.85)
    # I am splitting my data as %70, %15, %15 as Prof. Hani Hagras suggested.
    train = norm_data[:t70]
    val   = norm_data[t70:t85]
    test  = norm_data[t85:]

    write_csv("train_norm.csv", train)
    write_csv("val_norm.csv", val)
    write_csv("test_norm.csv", test)

    # Finally I saved scaling parameters to give to NeuralNetHolder.py
    f = open("scale.txt","w")
    for i in range(4):
        f.write(str(mins[i]) + "," + str(maxs[i]) + "\n")
    f.close()

    print("Preprocess finished.")

if __name__ == "__main__":
    main()