import math
import random

INPUT_N = 3  
HIDDEN_N = 12
OUTPUT_N = 2
LR = 0.03
MOM = 0.7
EPOCHS = 100

def read_csv(path):
    rows = []
    f = open(path,"r")
    for line in f:
        p = line.strip().split(",")
        if len(p)!=4: continue
        rows.append([float(p[0]), float(p[1]), float(p[2]), float(p[3])])
    f.close()
    return rows

def init_matrix(r,c):
    return [[random.uniform(-0.5,0.5) for _ in range(c)] for _ in range(r)]

def init_vector(n):
    return [random.uniform(-0.5,0.5) for _ in range(n)]

def relu(x):
    return x if x>0 else 0

def drelu(x):
    return 1 if x>0 else 0

def forward(x, W1, b1, W2, b2):
    h = []
    for j in range(HIDDEN_N):
        s = b1[j]
        for i in range(INPUT_N):
            s += x[i] * W1[i][j]
        h.append(relu(s))

    y = []
    for k in range(OUTPUT_N):
        s = b2[k]
        for j in range(HIDDEN_N):
            s += h[j] * W2[j][k]
        y.append(s)
    return h, y

def train():
    train_data = read_csv("train_norm.csv")

    W1 = init_matrix(INPUT_N, HIDDEN_N)
    b1 = init_vector(HIDDEN_N)
    W2 = init_matrix(HIDDEN_N, OUTPUT_N)
    b2 = init_vector(OUTPUT_N)

    dW1_old = init_matrix(INPUT_N, HIDDEN_N)
    db1_old = init_vector(HIDDEN_N)
    dW2_old = init_matrix(HIDDEN_N, OUTPUT_N)
    db2_old = init_vector(OUTPUT_N)
    
    MAXH = 1.0

    for ep in range(EPOCHS):
        total_loss = 0

        for row in train_data:
            x_dist = row[0]
            y_dist = row[1]

            gravity = y_dist / MAXH

            x = [x_dist, y_dist, gravity]

            target = [row[2], row[3]]

            h, y = forward(x, W1, b1, W2, b2)

            err = [y[i]-target[i] for i in range(2)]
            total_loss += (err[0]**2 + err[1]**2)

            # BACKPROP
            dW2 = init_matrix(HIDDEN_N, OUTPUT_N)
            db2 = init_vector(OUTPUT_N)

            for k in range(OUTPUT_N):
                db2[k] = err[k]
                for j in range(HIDDEN_N):
                    dW2[j][k] = err[k] * h[j]

            dW1 = init_matrix(INPUT_N, HIDDEN_N)
            db1 = init_vector(HIDDEN_N)

            for j in range(HIDDEN_N):
                dh = 0
                for k in range(OUTPUT_N):
                    dh += err[k] * W2[j][k]
                dh *= drelu(h[j])

                db1[j] = dh
                for i in range(INPUT_N):
                    dW1[i][j] = dh * x[i]

            # UPDATE
            for i in range(INPUT_N):
                for j in range(HIDDEN_N):
                    dW1_old[i][j] = MOM*dW1_old[i][j] - LR*dW1[i][j]
                    W1[i][j] += dW1_old[i][j]

            for j in range(HIDDEN_N):
                db1_old[j] = MOM*db1_old[j] - LR*db1[j]
                b1[j] += db1_old[j]

            for j in range(HIDDEN_N):
                for k in range(OUTPUT_N):
                    dW2_old[j][k] = MOM*dW2_old[j][k] - LR*dW2[j][k]
                    W2[j][k] += dW2_old[j][k]

            for k in range(OUTPUT_N):
                db2_old[k] = MOM*db2_old[k] - LR*db2[k]
                b2[k] += db2_old[k]

        rmse = math.sqrt(total_loss / len(train_data))
        print("Epoch", ep, "RMSE:", rmse)

    # SAVE
    f = open("weights.txt","w")
    for i in range(INPUT_N):
        f.write(",".join(str(x) for x in W1[i]) + "\n")
    f.write("B1:" + ",".join(str(x) for x in b1) + "\n")
    for j in range(HIDDEN_N):
        f.write(",".join(str(x) for x in W2[j]) + "\n")
    f.write("B2:" + ",".join(str(x) for x in b2) + "\n")
    f.close()

    print("Training finished.")

if __name__=="__main__":
    train()
